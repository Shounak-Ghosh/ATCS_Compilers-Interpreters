public class InputNode extends StmtNode
{

}
