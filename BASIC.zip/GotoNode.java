public class GotoNode extends StmtNode
{
    private final String type = "GOTO";
    private StmtNode goneTo;

    public GotoNode(StmtNode s)
    {
        goneTo = s;
    }

    public void exec(EvalState evalState)
    {
        goneTo.exec(evalState);
    }

}
