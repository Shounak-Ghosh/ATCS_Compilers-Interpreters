import java.util.HashMap;

public class EvalState
{
    private HashMap<String, Integer> variables;

    public EvalState()
    {
        variables = new HashMap<String, Integer>();
    }

    public void putVariable(String var, int val)
    {
        variables.put(var,val);
    }

    public int getVariable(String var)
    {
        return variables.get(var);
    }
}
