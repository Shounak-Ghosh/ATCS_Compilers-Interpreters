public class RemNode extends StmtNode
{
    private final String type = "REM";
    private String comment;

    public RemNode(String line)
    {
        comment = line;
    }

    public void eval(EvalState evalState)
    {
        // empty because comments are not executed
    }

    public String getType()
    {
        return type;
    }
}
