import java.util.TreeMap;

public class Program
{
    private TreeMap<Integer,Statement> statements;

    public Program()
    {
        statements = new TreeMap<Integer, Statement>();
    }


    // if a statement with the same line number exists in
    // the program, then replace that statement with the
    // parameter, otherwise add the statement to the program
    public void addStatement(Statement s)
    {
        statements.put(s.getLineNumber(),s);
    }

    // if a statement with the same line number exists in
    // the program, then replace that statement with the
    // parameter, otherwise add the statement to the program
    public void removeStatement(int lineNumber)
    {
       statements.remove(lineNumber);
    }

    // get the statement with the specified line number. If
    // no statement exists with the given line number, the
    // method returns null
    public Statement getStatement(int lineNumber)
    {
        if(statements.containsKey(lineNumber))
        {
            return statements.get(lineNumber);
        }
        return null;
    }

    // get the line number of the first statement in the
    // program. If the program contains no lines, this method
    // returns -1
    public int getFirstLineNumber()
    {
        if(!statements.isEmpty())
        {
            return statements.firstKey();
        }
        return -1;
    }

    // Returns the line number of the first line in the program // whose number is larger than the specified one, which
    // must already exist in the program. If no more lines
    // remain, this method returns -1.
    public int getNextLineNumber(int lineNumber)
    {
        for(Integer currentNum: statements.keySet())
        {
            if (currentNum >= lineNumber)
            {
                return currentNum;
            }
        }
        return -1;
    }

    public void getList()
    {
        for(Integer lineNum: statements.keySet())
        {
            System.out.println(statements.get(lineNum));
        }
    }

    public void runProgram()
    {
        EvalState e = new EvalState();
        // todo loop below is not correct, execution should stop when an EndNode is reached
        for(Integer lineNum: statements.keySet())
        {
            statements.get(lineNum).getParsedStatement().exec(e);
        }
    }

}
