public class PrintNode extends StmtNode
{
    ExpressionNode expr;

    public PrintNode(ExpressionNode e)
    {
        expr = e;
    }


    public void exec(EvalState evalState)
    {
        System.out.println(expr.eval(evalState));
    }
}
