public class VariableNode
{
    private String name;

    public VariableNode(String n)
    {
        name = n;
    }

    public int eval(EvalState evalState)
    {
        return evalState.getVariable(name);
    }
}
