// todo figure out what needs to be done with this class
//public class FactorNode
//{
//    NumberNode value;
//
//    public FactorNode()
//
//    public int eval(EvalState evalState)
//    {
//        return -1;
//    }
//}
