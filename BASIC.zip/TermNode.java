public class TermNode
{
    private String operand;
    private NumberNode left;
    private TermNode right;
    public TermNode(String op, NumberNode l, TermNode r)
    {
        operand = op;
        left = l;
        right = r;
    }

    // todo method stub
    public int eval(EvalState evalState)
    {
       if(operand.equals("+"))
       {
           return left.eval(evalState) + right.eval(evalState);
       }
       return left.eval(evalState) - right.eval(evalState);
    }
}
