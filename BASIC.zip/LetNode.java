public class LetNode extends StmtNode
{
    private String var;
    private ExpressionNode expr;

    public LetNode(String v, ExpressionNode e)
    {
        var = v;
        expr = e;
    }


    public void exec(EvalState evalState)
    {
        evalState.putVariable(var,expr.eval(evalState));
    }
}
