public class Statement
{
    private int lineNumber;
    private String statement;
    private StmtNode astNode;

    public Statement(int lineNum, String line, StmtNode node)
    {
        lineNumber = lineNum;
        statement = line;
        astNode = node;

    }

    public int getLineNumber()
    {
        return lineNumber;
    }


    public String getSourceString()
    {
        return statement;
    }


    public StmtNode getParsedStatement()
    {
        return astNode;
    }

    public String toString()
    {
        return lineNumber + " " + statement;
    }
}
