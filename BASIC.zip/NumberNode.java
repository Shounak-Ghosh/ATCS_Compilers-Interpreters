public class NumberNode
{
    private int value;

    public NumberNode(int val)
    {
        value = val;
    }

    public int eval(EvalState evalState)
    {
        return value;
    }
}
