public class ExpressionNode
{
    private String operand;
    private TermNode left;
    private ExpressionNode right;

    public ExpressionNode(String op, TermNode l, ExpressionNode r)
    {
        operand = op;
        left = l;
        right = r;
    }

    public int eval(EvalState evalState)
    {
        if(operand.equals("*"))
        {
            return left.eval(evalState) * right.eval(evalState);
        }
        return left.eval(evalState) / right.eval(evalState);
    }
}
