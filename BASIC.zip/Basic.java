import java.util.Scanner;
import java.util.StringTokenizer;

public class Basic
{
    public static void main(String[] args)
    {
        Program program = new Program();
        Scanner sc = new Scanner(System.in);
        boolean stopReading = false;
        StringTokenizer st;

        while (!stopReading)
        {
            String current = sc.nextLine();
            String temp = "";
            st = new StringTokenizer(current);
            int lineNum = -1;

            try
            {
                temp = st.nextToken();
                lineNum = Integer.parseInt(temp);
            }
            catch (Exception e)
            {
                //e.printStackTrace();
            }

            if(lineNum > 0)
            {
                if(current.length() == temp.length())
                {
                    program.removeStatement(lineNum);
                }
                else
                {
                    String source = current.substring(temp.length());
                    // todo should StmtNode should be assigned based on type
                    temp = st.nextToken();
                    // todo can be changed to a
                    if(temp.equals("REM"))
                    {
                        program.addStatement(new Statement(lineNum,current,new RemNode(current)));
                    }
                    else if(temp.equals("LET"))
                    {

                    }
                    else if(temp.equals("PRINT"))
                    {

                    }
                    else if(temp.equals("INPUT"))
                    {

                    }
                    else if(temp.equals("GOTO"))
                    {

                    }
                    else if(temp.equals("IF"))
                    {

                    }
                    else if(temp.equals("END"))
                    {

                    }
                }
            }
            // todo everything below can be converted to a switch statement
            // meta level commands, not included in the program
            else if(current.equals("RUN"))
            {
                // run program as is
                EvalState e = new EvalState();

            }
            else if(current.equals("LIST"))
            {
                // sort the statements in order of line number and print program
                program.getList();

            }
            else if(current.equals("CLEAR"))
            {
                // clear current program (replace the program object)
                program = new Program();

            }
            else if(current.equals("HELP"))
            {
                // help?
            }
            else if(current.equals("QUIT"))
            {
                stopReading = true;
            }
        }
    }
}
