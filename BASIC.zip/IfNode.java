import java.beans.Expression;

public class IfNode
{
    // todo complete after a working GOTO
    ExpressionNode left;
    ExpressionNode right;
    String operand;
    int lineNum;

    public IfNode(String op, ExpressionNode l, ExpressionNode r, int line)
    {
        operand = op;
        left = l;
        right = r;
        lineNum = line;
    }

    // todo method stub
    public int eval(EvalState evalState)
    {
        return -1;
    }
}
