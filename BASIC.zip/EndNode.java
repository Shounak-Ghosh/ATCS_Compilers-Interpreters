public class EndNode
{
    private final String type = "END";
}
