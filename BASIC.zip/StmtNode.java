// todo make abstract?
public class StmtNode
{
    public StmtNode()
    {

    }

    //todo dummy method
    public void exec(EvalState evalState)
    {

    }


}
