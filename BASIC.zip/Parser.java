public class Parser
{
    private Scanner myScanner;
    private Program program;

    p
}
