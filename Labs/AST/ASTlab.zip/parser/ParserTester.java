package parser;
import environment.Environment;
import scanner.ScanErrorException;
import scanner.Scanner;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Tester for the Parser class
 * @author Shounak Ghosh
 * @version 9.26.19
 */
public class ParserTester
{
    /**
     * Driver method; used for testing purposesr
     * @param args Command-line arguement
     * @throws IOException thrown in the case of a file-reading error
     * @throws ScanErrorException thrown if there is an input-mismatch exception
     */
    public static void main(String[] args) throws IOException, ScanErrorException
    {
        for (int i = 0; i <= 5; i++)
        {
            parse("parserText" + i + ".txt");
        }
    }

    /**
     * Parses a given file
     * @param filename the name of the file to parse from
     * @throws IOException thrown in the case of a file-reading error
     * @throws ScanErrorException thrown if there is an input-mismatch exception
     */
    public static void parse(String filename) throws IOException, ScanErrorException
    {
        System.out.println(filename);
        InputStream inputstream = new FileInputStream(filename);
        Scanner scanner = new Scanner(inputstream);
        Parser parser = new Parser(scanner);
        Environment env = new Environment();
        while (scanner.hasNext())
        {
            parser.parseStatement().exec(env);
        }
        System.out.println();


    }

}
