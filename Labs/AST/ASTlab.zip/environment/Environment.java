package environment;

import java.util.HashMap;

/**
 * Stores the state of all the variables created
 * @author Shounak Ghosh
 * @version 10.08.2019
 */
public class Environment
{
    private HashMap<String, Integer> variables;

    /**
     * Constructor; creates Environment objects
     */
    public Environment()
    {
        variables = new HashMap<String, Integer>();
    }

    /**
     * Associates the variable name with its value
     * @param variable the name of the variable
     * @param value the Integer value corresponding to the variable
     */
    public void setVariable (String variable, Integer value)
    {
        variables.put(variable,value);
    }

    /**
     * Retrieves the value of a variable, given its name
     * @param variable the name of the variable
     * @return the value associated with the variable
     */
    public int getVariable(String variable)
    {
        return variables.get(variable);
    }

}
