package ast;

import environment.Environment;

/**
 * The IF class evaluates an Expression if a given Conditional is true
 * @author  Shounak Ghosh
 * @version 10.08.2019
 */
public class If extends Statement
{
    private Condition condition;
    private Statement statement;

    /**
     * Constructor; creates If objects
     * @param cond the condition required in order to execute the statement
     * @param s the statement executed if the condition is satisfied
     */
    public If (Condition cond, Statement s)
    {
        condition = cond;
        statement = s;
    }

    /**
     * If the condition is true, the statement is executed
     * @param env  stores the state of the variables in use
     */
    public void exec(Environment env)
    {
        if(condition.eval(env) == 0)
        {
            statement.exec(env);
        }
    }
}
