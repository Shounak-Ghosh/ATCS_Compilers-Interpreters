package ast;
import environment.Environment;

/**
 * The abstract Expression class represents the components of
 * the AST that are evaluated to an integer value
 * @author Shounak Ghosh
 * @version 10.08.2019
 */
public abstract class Expression
{
    /**
     * Calculates the numerical value of this
     * @param env  stores the state of the variables in use
     * @return the integer value resulting from evaluating this
     * */
    public abstract int eval(Environment env);
}
