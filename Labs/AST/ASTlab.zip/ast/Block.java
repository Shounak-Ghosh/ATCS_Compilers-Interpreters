package ast;
import environment.Environment;

import java.util.ArrayList;

/**
 * The Block class executes a specified List of Statements
 * @author Shounak Ghosh
 * @version 10.08.2019
 */
public class Block extends Statement
{
    private ArrayList<Statement> statements;

    /**
     * Constructor; creates Block objects
     * @param statements the List of statements within the BEGIN/END statement
     */
    public Block(ArrayList<Statement> statements)
    {
        this.statements = statements;
    }

    /**
     * Executes all the statements within the BEGIN/END statement
     * @param env  stores the state of the variables in use
     */
    public void exec(Environment env)
    {
        for (int i = 0; i < statements.size(); i++)
        {
            statements.get(i).exec(env);
        }
    }
}
