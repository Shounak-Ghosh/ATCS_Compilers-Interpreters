package ast;
import environment.Environment;

/**
 * The abstract class Statement represents the
 * different kinds of statements that can be parsed in: IF, WHILE,
 * BEGIN/END, and WRITELN
 * @author Shounak Ghosh
 * @version 10.08.2019
 */
public abstract class Statement
{
    /**
     * Executes the different components of the AST
     * @param env  stores the state of the variables in use
     */
    public abstract void exec(Environment env);
}
