package parser;
import scanner.ScanErrorException;
import scanner.Scanner;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Tester for the Parser class
 * @author Shounak Ghosh
 * @version 9.26.19
 */
public class ParserTester
{
    public static void main(String[] args) throws IOException, ScanErrorException
    {
        for (int i = 0; i <= 4; i++)
        {
            parse("parserText" + i + ".txt");
        }
    }


    public static void parse(String filename) throws IOException, ScanErrorException
    {
        System.out.println(filename);
        InputStream inputstream = new FileInputStream(filename);
        Scanner scanner = new Scanner(inputstream);
        Parser parser = new Parser(scanner);
        while (scanner.hasNext())
        {
            parser.parseStatement();
        }
        System.out.println();
    }

}
