import scanner.ScanErrorException;
import scanner.Scanner;
import java.util.HashMap;

/**
 * The Parser class parses the tokens read in by the Scanner
 * and evaluates the statements parsed in
 * @author Shounak Ghosh
 * @version 9.26.19
 */
public class Parser
{
    Scanner myScanner;
    String currentToken;
    HashMap<String,Integer> variables;

    /**
     * Constructor, creates Parser objects
     * @param in The Scanner used to read in the HHL code
     * @throws ScanErrorException thrown if an invalid/unexpected token is parsed in
     */
    public Parser(Scanner in) throws ScanErrorException
    {
        myScanner = in;
        currentToken = myScanner.nextToken();
        variables = new HashMap<>();
    }

    /**
     * Checks whether currentChar and the parameter are equal
     * @param expected the character currentChar is being compared to
     * @throws ScanErrorException thrown if an invalid/unexpected token is parsed in
     */
    private void eat(String expected) throws ScanErrorException
    {
        if(!expected.equals(currentToken))
        {
            throw new IllegalArgumentException("IllegalArguementException: Expected \""
                                               + expected + "\", Found \"" + currentToken + "\"");
        }
        if(myScanner.hasNext())
        {
            currentToken = myScanner.nextToken();
        }

    }

    /**
     * Parses an IF statement; reads in tokens until a semicolon is reached
     * @throws ScanErrorException thrown if an invalid/unexpected token is parsed in
     */
    private void parseIf() throws ScanErrorException
    {
        //System.out.println(currentToken);
        eat("IF");
        // continue until semicolon is read in
        while (!currentToken.equals(";"))
        {
            System.out.println(currentToken);
            eat(currentToken);
        }
        eat(currentToken);
        //System.out.println("CURRENT TOK " + currentToken);
    }


    /**
     * Precondition: current token is a number, represented as a String
     * Parses in a number, a NumberFormatException error is thrown if
     * the precondition is not met-
     * @return the numerical value parsed in
     * @throws ScanErrorException thrown if an invalid/unexpected token is parsed in
     */
    private int parseNumber() throws ScanErrorException
    {
        int n = Integer.parseInt(currentToken); // can screw up
        eat(currentToken);
        return n;
    }

 // todo check if parseStatement() is implemented correctly (not brute forced)

    /**
     * Parses in WRITELN, BEGIN/END, and variable statements
     * @throws ScanErrorException thrown if an invalid/unexpected token is parsed in
     */
    public void parseStatement() throws ScanErrorException
    {
//        System.out.println("REACHED STATEMENT " + currentToken);
        if(currentToken.equals("BEGIN"))
        {
            eat("BEGIN");
            while (!currentToken.equals("END"))
            {
                parseStatement();
            }
            //parseStatement();
            eat("END");
            eat(";");
        }
        else if(currentToken.equals("WRITELN"))
        {
            eat("WRITELN");
            eat("(");
            System.out.println(parseExpression());
            eat(")");
            eat(";");
        }
        else
        {
            String id = currentToken;
            eat(currentToken);
            eat(":=");
            int val = parseExpression();
            variables.put(id,val);
            eat(";");
        }
    }

    /**
     * Parses and evaluates mathematical expressions involving addition and subtraction
     * @return the value of the expression evaluated
     * @throws ScanErrorException thrown if an invalid/unexpected token is parsed in
     */
    private int parseExpression() throws ScanErrorException
    {
//        System.out.println("REACHED EXPRESSION "  + currentToken);
        int ans = parseTerm();
        // insert code here
        while (currentToken.equals("+") || currentToken.equals("-"))
        {
            if(currentToken.equals("+"))
            {
                eat(currentToken);
                ans += parseTerm();
            }
            else // subtraction
            {
                eat(currentToken);
                ans -= parseTerm();
            }
        }
        return ans;
    }

    /**
     * Parses and evaluates mathematical terms involving division and multiplication
     * @return the value of the term evaluated
     * @throws ScanErrorException thrown if an invalid/unexpected token is parsed in
     */
    private int parseTerm() throws ScanErrorException
    {
//        System.out.println("REACHED TERM " + currentToken);
        int ans = parseFactor();
        // insert code here
        while (currentToken.equals("*") || currentToken.equals("/"))
        {
            if(currentToken.equals("*"))
            {
                eat(currentToken);
                ans *= parseFactor();
            }
            else // division
            {
                eat(currentToken);
                ans /= parseFactor();
            }
        }
        return ans;
    }

    /**
     * Parses in integers, variables and expressions
     * @return the value of the integer, variable or expression parsed in
     * @throws ScanErrorException thrown if an invalid/unexpected token is parsed in
     */
    private int parseFactor() throws ScanErrorException
    {
        int temp;
//        System.out.println("REACHED FACTOR " + currentToken);
        if(currentToken.equals("-"))
        {
            eat(currentToken);
            return -1 * parseFactor();
        }
        else if(currentToken.equals("("))
        {
            eat("(");
            temp = parseExpression();
            eat(")");
            return temp;
        }
        else if(variables.containsKey(currentToken))
        {
            temp = variables.get(currentToken);
            eat(currentToken);
            return temp;
        }
        return parseNumber();
    }

}