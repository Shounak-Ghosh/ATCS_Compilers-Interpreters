import scanner.ScanErrorException;
import scanner.Scanner;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Tester for the Parser class
 * @author Shounak Ghosh
 * @version 9.26.19
 */
public class ParserTester
{
    public static void main(String[] args) throws IOException, ScanErrorException
    {
        InputStream inputstream = new FileInputStream("ScannerText.txt");
        Scanner scanner = new Scanner(inputstream);
        Parser parser = new Parser(scanner);
        while (scanner.hasNext())
        {
            parser.parseStatement();
        }
    }
}
