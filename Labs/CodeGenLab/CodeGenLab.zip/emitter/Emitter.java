package emitter;
import java.io.*;

/**
 *
 */
public class Emitter
{
	private PrintWriter out;
	private int labelNum = 0;
    //creates an emitter for writing to a new file with given name

	/**
	 *
	 * @param outputFileName
	 */
	public Emitter(String outputFileName)
	{
		try
		{
			out = new PrintWriter(new FileWriter(outputFileName), true);
		}
		catch(IOException e)
		{
			throw new RuntimeException(e);
		}
	}


	/**
	 * Prints one line of code to file (with non-labels indented)
	 * @param code the MIPS assembly code to be printed
	 */
	public void emit(String code)
	{
		if (!code.contains(":") && !code.contains("."))
			code = "\t" + code;
		out.println(code);
	}

	//closes the file.  should be called after all calls to emit.
	public void close()
	{
		out.close();
	}


	/**
	 * Pushes the value stored in the given register to the memory stack
	 * @param reg the name of the register to be pushed to the memory stack
	 */
	public void emitPush(String reg)
	{
		emit("subu $sp $sp 4");
		emit("sw " + reg + "  ($sp) #push " + reg);
	}

	/**
	 * Pops the topmost value of the memory stack
	 * @param reg the name of the register that will store
	 *               the value popped off the memory stack
	 */
	public void emitPop(String reg)
	{
		emit("lw " + reg + "  ($sp) #pop " + reg);
		emit("addu $sp $sp 4");
	}

	/**
	 * Retrieves the next id available for MIPS label names
	 * @return the next available integer id
	 */
	public int nextLabelID()
	{
		labelNum++;
		return labelNum;
	}
}