package ast;

import emitter.Emitter;
import environment.Environment;

import java.util.ArrayList;

/**
 * ProcedureDeclaration objects store the name of the procedure,
 * the list of formal parameters of the object,
 * and the statement to be executed if the procedure is called
 * @author Shounak Ghosh
 * @version 10.19.2019
 */
public class ProcedureDeclaration extends Statement
{
    private String name;
    private Statement statement;
    private ArrayList<String> parameters;

    /**
     * Constructor: Creates Procedure declaration objects
     * @param n the name of the procedure
     * @param s the statement to be executed when the procedure is called
     * @param params a list of formal parameters
     */
    public ProcedureDeclaration(String n, Statement s, ArrayList<String> params)
    {
        name = n;
        statement = s;
        parameters = params;
    }

    /**
     * Retrieves the procedure's statement
     * @return the procedure's statement
     */
    public Statement getStatement()
    {
        return statement;
    }

    /**
     * Retrieves the name of the procedure
     * @return the name of the procedure
     */
    public String getName()
    {
        return  name;
    }

    /**
     * Retrieves the list of formal parameters of the procedure
     * @return the list of formal paramters of the procedure
     */
    public ArrayList<String> getParameters()
    {
        return parameters;
    }

    /**
     * Executes the given Procedure declaration
     * @param env stores the state of the variables in use
     */
    public void exec(Environment env)
    {
        env.setProcedure(name,this);
    }

    /**
     *
     * @param e emits the MIPS assembly code
     */
    public void compile(Emitter e)
    {
        throw new RuntimeException("Implement me!!!!!");
    }
}
