package ast;
import emitter.Emitter;
import environment.Environment;
import java.util.ArrayList;

/**
 * ProcedureCall objects evaluate a ProcedureDeclaration
 * by substituting the actual parameters passed in
 * @author Shounak Ghosh
 * @version 10.19.2019
 */
public class ProcedureCall extends Expression
{
    private String name;
    private ArrayList<Expression> actualParameters;

    /**
     * Constructor: Creates ProcedureCall objects
     * @param n the name of the procedure
     * @param actualParams the actual parameters passed into the procedure
     */
    public ProcedureCall(String n, ArrayList<Expression> actualParams)
    {
        name = n;
        actualParameters = actualParams;
    }

    /**
     * Evaluates a procedure call
     * @param env stores the state of the variables in use
     * @return the return value of the procedure; 0 is the default
     */
    public int eval(Environment env)
    {
        Environment local = new Environment(env);
        local.declareVariable(name,0);
        ProcedureDeclaration current = env.getProcedure(name);
        for (int i = 0; i < current.getParameters().size(); i++)
        {
            local.declareVariable(current.getParameters().get(i),actualParameters.get(i).eval(env));
        }
        current.getStatement().exec(local);
        return local.getVariable(name);
    }

    /**
     *
     * @param e emits the MIPS assembly code
     */
    public void compile(Emitter e)
    {
        throw new RuntimeException("Implement me!!!!!");
    }


}
