package ast;

import environment.Environment;

import java.util.ArrayList;

/**
 * Program objects stores a list of procedure declarations as well
 * as the program statement
 * @author Shounak Ghosh
 * @version 10.20.2019
 */
public class Program extends Statement
{
    private ArrayList<ProcedureDeclaration> procedureDeclarations;
    private Statement statement;

    /**
     * Constructor: Creates Program objects
     * @param pd an ArrayList of ProcedureDeclaration objects
     * @param s the program Statement to be exeecuted
     */
    public Program(ArrayList<ProcedureDeclaration> pd, Statement s)
    {
        procedureDeclarations = pd;
        statement = s;
    }

    /**
     * Executes each of the Procedure declarations, and then the program statement
     * @param env stores the state of the variables and procedures in use
     */
    public void exec(Environment env)
    {
        for (ProcedureDeclaration pd: procedureDeclarations)
        {
            pd.exec(env);
        }
        statement.exec(env);
    }

}
